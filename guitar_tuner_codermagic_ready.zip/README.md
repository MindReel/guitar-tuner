Guitar Tuner - Replit-ready (Simple version)

Steps to build APK on Replit:

1. Create a free account at https://replit.com
2. Create a new Repl using the **Gradle** template (search "Gradle" when creating).
3. Delete default files in the Repl, then upload the contents of this ZIP (keep the folder structure).
4. In the Replit console, run:
   ./gradlew assembleDebug
5. After build completes, download APK from:
   app/build/outputs/apk/debug/app-debug.apk

If ./gradlew fails, try running: gradle wrapper && ./gradlew assembleDebug
Replit usually provides a Gradle runtime in the Gradle template; if not, use a machine with Gradle/Android SDK or try a different online builder.
