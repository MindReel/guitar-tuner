rootProject.name = "GuitarTuner"
include(":app")
